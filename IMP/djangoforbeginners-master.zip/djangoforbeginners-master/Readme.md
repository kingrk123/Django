The official source code for _Django for Beginners_.

![Cover](bookcover.jpg)

Preview the book at [https://djangoforbeginners.com/](https://djangoforbeginners.com/).

Available as an [ebook (with free updates)](https://gum.co/aFiMm), [Paperback](https://www.amazon.com/dp/1983172669/?tag=wsvincent-20), or [Kindle](https://www.amazon.com/dp/B079ZZLRRL/?tag=wsvincent-20).
