The official source code for _Django for APIs_. Previously titled _REST APIs with Django_.

![Cover](cover_2_2.jpg)

Preview the book at [https://djangoforapis.com/](https://djangoforapis.com/).

Available as an [ebook (with free updates)](https://gum.co/EzsI), [Paperback](https://www.amazon.com/dp/198302998X/?tag=wsvincent-20), or [Kindle](https://www.amazon.com/dp/B07DR9XS6L/?tag=wsvincent-20).
